<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "category".
 *
 * @property int $categoryId
 * @property int $shoeId
 * @property string $category
 *
 * @property Shoes $shoe
 */
class Category extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'category';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['shoeId', 'category'], 'required'],
            [['shoeId'], 'integer'],
            [['category'], 'string', 'max' => 255],
            [['shoeId'], 'unique'],
            [['shoeId'], 'exist', 'skipOnError' => true, 'targetClass' => Shoes::className(), 'targetAttribute' => ['shoeId' => 'shoeId']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'categoryId' => 'Category ID',
            'shoeId' => 'Shoe ID',
            'category' => 'Category',
        ];
    }

    /**
     * Gets query for [[Shoe]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getShoe()
    {
        return $this->hasOne(Shoes::className(), ['shoeId' => 'shoeId']);
    }
}
