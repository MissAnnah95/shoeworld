<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\bootstrap4\Modal;
use frontend\models\Category;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model frontend\models\Shoes */
/* @var $form yii\widgets\ActiveForm */

// $category = ArrayHelper::map(Category::find()->all(), 'shoeId', 'categoryId');
?>

<div class="shoes-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="container">
      <div class="col-xs-12">
        <?= $form->field($model, 'shoeName')->textInput(['maxlength' => true]) ?>
      </div>

      <!-- <div class="row"> -->
        <div class="col-xs-12">
          <?= $form->field($model, 'price')->textInput() ?>
        </div>

        <!-- <div class="col-xs-4">
             <button type="button" class="btn btn-block btn-success addcategory"><i class="fa fa-plus" aria-hidden="true"></i> Add Category</button>
          </div>
      </div> -->


        <div class="col-xs-12">
          <?= $form->field($model, 'description')->textarea(['rows' => 1]) ?>
        </div>


      <div class="form-group">
        <?= Html::submitButton('<span class="fa fa-forward"></span> Next', ['class' => 'btn btn-success']) ?>
      </div>

    </div>


    <?php ActiveForm::end(); ?>

</div>

<!-- <?php
        // Modal::begin([
        //     'title'=>'<h4>Category </h4>',
        //     'id'=>'addcategory',
        //     'size'=>'modal-lg'
        //     ]);
        //
        // echo "<div id='addcategoryContent'></div>";
        // Modal::end();
      ?> -->
