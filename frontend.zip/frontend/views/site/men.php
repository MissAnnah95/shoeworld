

<div class="container-fluid text-dark bg-no-overlay" style="background: url("images/M2.jpg"); background-size: cover;">
    <div class="row justify-content-center">
        <div>
            <h1 class="text-center font-italic">Crazy offers<br> for the merry season.</h1>
        <br><br>
        </div>

    </div>
</div>



<!-- pictures of shoes -->
<div class="container-fluid">
<div class="row justify-content-center">
  <div>
    <h1 class="mt-5 text-center">Going for an important occasion?</h1>
    <h5 class="mt-3 text-center">Then pick your taste.</h5>
    <hr class="bg-dark">

  </div>
  </div>
</div>

<div class="container">
<div class="row">
    <div class="col-sm-4">
        <div class="card-8 mt-5">
            <img class="card-img" src="<?= Yii::$app->request->baseUrl ?>/images/S1.jpg">
          </div>
          <p class="card-text"><strong>Product Name</strong><br>Kshs 3,500</p>
    </div>
    <div class="col-sm-4">
        <div class="card-8 mt-5">
            <img class="card-img" src="<?= Yii::$app->request->baseUrl ?>/images/S5.jpg">
          </div>
          <p class="card-text"><strong>Product Name</strong><br>Kshs 3,500</p>
    </div>
    <div class="col-sm-4">
        <div class="card-8 mt-5">
            <img class="card-img" src="<?= Yii::$app->request->baseUrl ?>/images/mens.jpg">
          </div>
          <p class="card-text"><strong>Product Name</strong><br>Kshs 3,500</p>
    </div>
    <div class="col-sm-4">
        <div class="card-8 mt-5">
            <img class="card-img" src="<?= Yii::$app->request->baseUrl ?>/images/S4.jpg">
          </div>
          <p class="card-text"><strong>Product Name</strong><br>Kshs 3,500</p>
    </div>
    <div class="col-sm-4">
        <div class="card-8 mt-5">
            <img class="card-img" src="<?= Yii::$app->request->baseUrl ?>/images/S6.jpg">
          </div>
          <p class="card-text"><strong>Product Name</strong><br>Kshs 3,500</p>
    </div>
    <div class="col-sm-4">
        <div class="card-8 mt-5">
            <img class="card-img" src="<?= Yii::$app->request->baseUrl ?>/images/S6.jpg">
          </div>
          <p class="card-text"><strong>Product Name</strong><br>Kshs 3,500</p>
    </div>
    <div class="col-sm-4">
        <div class="card-8 mt-5">
            <img class="card-img" src="<?= Yii::$app->request->baseUrl ?>/images/S2.jfif">
          </div>
          <p class="card-text"><strong>Product Name</strong><br>Kshs 3,500</p>
    </div>
    <div class="col-sm-4">
        <div class="card-8 mt-5">
            <img class="card-img" src="<?= Yii::$app->request->baseUrl ?>/images/S1.jpg">
          </div>
          <p class="card-text"><strong>Product Name</strong><br>Kshs 3,500</p>
    </div>
    <div class="col-sm-4">
        <div class="card-8 mt-5">
            <img class="card-img" src="<?= Yii::$app->request->baseUrl ?>/images/S1.jpg">
          </div>
          <p class="card-text"><strong>Product Name</strong><br>Kshs 3,500</p>
    </div>
</div>
</div>
